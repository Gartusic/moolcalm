package com.moolcalm.domain;

import lombok.Data;

@Data
public class CollectionVO {
	private String email;
	private String p_name;
}
